# youtube-playback-control
Chrome extension to control playback of all youtube tabs playing videos

![screenshot](/media/screenshot1.png?raw=true)

This is a chrome extension which will allow you to play or pause youtube videos running across all tabs in all windows. Press the row containing title and it toggles the state of tab playing youtube video. You need to reload tabs once after installing the extension.

Download the extension here: 

https://chrome.google.com/webstore/detail/youtube-playback-control/okbcoijdeebocmahlanbfemnckjonfnh
